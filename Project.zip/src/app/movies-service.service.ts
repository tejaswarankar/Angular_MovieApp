import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class MoviesServiceService {

  constructor(private _httpClient: HttpClient) { }

  GetMoviesGenres() {
    return this._httpClient.get<any>("https://api.themoviedb.org/3/genre/movie/list?api_key=68e82445c8842ba8616d0f6bf0e97a41")
      .pipe(
        map(result => {
          return result;
        }),
      );
  }
  GetMoviesByGenre(GenreId: any) {
    return this._httpClient.get<any>("https://api.themoviedb.org/3/genre/" + GenreId + "/movies?api_key=68e82445c8842ba8616d0f6bf0e97a41")
      .pipe(
        map(result => {
          return result;
        }),
      );
  }
}
