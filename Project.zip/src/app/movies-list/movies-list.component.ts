import { Component, OnInit } from '@angular/core';
import { MoviesServiceService } from '../movies-service.service';
declare let $: any;

@Component({
  selector: 'app-movies-list',
  templateUrl: './movies-list.component.html',
  styleUrls: ['./movies-list.component.scss'],
  providers: [MoviesServiceService]
})
export class MoviesListComponent implements OnInit {
  MoviesGenresList: any;
  MoviesList: Movies[] = [];
  title = 'MoviesApp';
  constructor(private movieService: MoviesServiceService) {

  }
  ngOnInit() {
    this.GetGenres();

    //  this.GetMoviesByGenre(16);
  }
  GetGenres() {
    this.movieService.GetMoviesGenres().subscribe(async data => {
      this.MoviesGenresList = data.genres;
      for (let i = 0; i < this.MoviesGenresList.length; i++) {
        let movie = new Movies();
        movie.GenreId = this.MoviesGenresList[i].id;
        movie.GenreName = this.MoviesGenresList[i].name;
        await this.GetMoviesByGenre(movie.GenreId).then(data => {
          movie.Movies = data;
        });
        this.MoviesList.push(movie);
      }
      for (let i = 0; i < this.MoviesGenresList.length; i++) {
        var width = 0;
        $('#overflow' + (i + 1) + ' .container div').each(function () {
          width += $(this).outerWidth(true);
        });
        $('#overflow' + (i + 1) + ' .container').css('width', width + "px");
      }
    });
  }
  GetMoviesByGenre(genreId) {
    return new Promise(resolve => {
      this.movieService.GetMoviesByGenre(genreId).subscribe(data => {
        resolve(data.results);
      })
    });

  }
  getMovieInfo(id){
    alert(id);
  }
}
export class Movies {
  GenreId: any;
  GenreName: any;
  Movies: any;
}
