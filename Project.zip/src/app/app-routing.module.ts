import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MovieInfoComponent } from './movie-info/movie-info.component';
import { MoviesListComponent } from './movies-list/movies-list.component';


const routes: Routes = [
  { path: '', pathMatch: 'full', component: MoviesListComponent },
  { path: 'MovieInfo/{id}', component: MovieInfoComponent, pathMatch: 'prefix' }];

@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
